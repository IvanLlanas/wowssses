#!/bin/bash
killall conky
sleep 2s
conky -c $HOME/.config/conky/corvo/corvo-diskio.conf &> /dev/null &
