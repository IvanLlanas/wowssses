#!/bin/bash
killall conky
sleep 2s
conky -c $HOME/.config/conky/inas/inas-diskio.conf &> /dev/null &
