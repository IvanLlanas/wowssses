#!/bin/bash
killall conky
sleep 2s
conky -c $HOME/.config/conky/ivan/ivan-diskio.conf &> /dev/null &
