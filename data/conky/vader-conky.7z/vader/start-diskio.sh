#!/bin/bash
killall conky
sleep 2s
conky -c $HOME/.config/conky/vader/vader-diskio.conf &> /dev/null &
