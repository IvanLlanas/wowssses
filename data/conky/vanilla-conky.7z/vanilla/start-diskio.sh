#!/bin/bash
killall conky
sleep 2s
conky -c $HOME/.config/conky/vanilla/vanilla-diskio.conf &> /dev/null &
